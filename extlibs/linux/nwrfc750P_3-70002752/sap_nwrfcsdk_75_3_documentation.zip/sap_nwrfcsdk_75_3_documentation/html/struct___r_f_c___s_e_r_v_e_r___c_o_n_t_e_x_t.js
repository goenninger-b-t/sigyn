var struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t =
[
    [ "isStateful", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#abea327b10e8075d8a1d85a29d4c4f8a6", null ],
    [ "sessionID", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a207f0d41096ce7d377a194a912e1f22f", null ],
    [ "tid", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#abc60d0479b6ae2895d06ea6bdb4a7968", null ],
    [ "type", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a74d22c358223c858de6e4acf0bef1a7b", null ],
    [ "unitAttributes", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#ae2acb7f8330409986df568236cb3a737", null ],
    [ "unitIdentifier", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a7ff76c4728c04654781c70659f6aeb27", null ]
];