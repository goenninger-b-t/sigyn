var group__structure =
[
    [ "RfcAddTypeField", "group__structure.html#ga3f92729d4663fe8b19b47687ebd8e34a", null ],
    [ "RfcCreateTypeDesc", "group__structure.html#ga6b4db8777f77d98f01214e6ac556bedc", null ],
    [ "RfcDestroyTypeDesc", "group__structure.html#ga7372895a5ea9f957d48bf3dda7698ee8", null ],
    [ "RfcGetFieldCount", "group__structure.html#ga6e6d12bfdb67f5e5c3f2c1b527249061", null ],
    [ "RfcGetFieldDescByIndex", "group__structure.html#ga628105df390b0e3f1fef0f924f1fec07", null ],
    [ "RfcGetFieldDescByName", "group__structure.html#ga4faf478a1b50d5a79ba738d20027643e", null ],
    [ "RfcGetTypeLength", "group__structure.html#ga65869e6bdc549d4607814859a9c3c2a0", null ],
    [ "RfcGetTypeName", "group__structure.html#ga31cfe9ff1a882978513b3d8f73a1ccd8", null ],
    [ "RfcSetTypeLength", "group__structure.html#ga63ea2c9806f63e4a2b974e88bc2ab846", null ]
];