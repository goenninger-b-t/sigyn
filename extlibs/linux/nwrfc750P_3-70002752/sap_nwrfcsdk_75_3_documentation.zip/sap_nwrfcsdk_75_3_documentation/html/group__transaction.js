var group__transaction =
[
    [ "_RFC_TRANSACTION_HANDLE", "struct___r_f_c___t_r_a_n_s_a_c_t_i_o_n___h_a_n_d_l_e.html", [
      [ "handle", "struct___r_f_c___t_r_a_n_s_a_c_t_i_o_n___h_a_n_d_l_e.html#adc77d96b032f332f9e4a4ae98f80e707", null ]
    ] ],
    [ "RfcConfirmTransaction", "group__transaction.html#ga02af32864ccc088e550106135c4ae06f", null ],
    [ "RfcCreateTransaction", "group__transaction.html#gabad5229528e6cb1ef7a36b8619edd39c", null ],
    [ "RfcDestroyTransaction", "group__transaction.html#ga7fdba7d86e62bc80414646f296e84503", null ],
    [ "RfcGetTransactionID", "group__transaction.html#ga879c7fdf9a2c39df26921709f0f278b5", null ],
    [ "RfcInvokeInTransaction", "group__transaction.html#gae2e25227b28465b6aec1b22b1fadb03b", null ],
    [ "RfcSubmitTransaction", "group__transaction.html#ga95aa9936eefd3cd806a1bfe5551e58cc", null ]
];