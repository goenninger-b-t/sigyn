var group__general =
[
    [ "RfcGetDirectionAsString", "group__general.html#ga9d128766b12da25536800f6986abd7a9", null ],
    [ "RfcGetRcAsString", "group__general.html#ga3f76cccd1a413427044e586cdd0865da", null ],
    [ "RfcGetServerStateAsString", "group__general.html#ga238d86f52eba3741bd5c3a74d41e0ba4", null ],
    [ "RfcGetSessionEventAsString", "group__general.html#ga8183f7ba0b3fce5bffa0300f8e4fa3b3", null ],
    [ "RfcGetTypeAsString", "group__general.html#ga96cb2ee4bdcdd1a58ce11aa4586bd294", null ],
    [ "RfcGetVersion", "group__general.html#gacbe7b5d43347a2105769a842f441de7c", null ],
    [ "RfcGetVersionInternal", "group__general.html#gae7841c2b02453a1af1ad227a53a7a294", null ],
    [ "RfcInit", "group__general.html#ga0a3e910393e5b1ba6a80611944d9df90", null ],
    [ "RfcLanguageIsoToSap", "group__general.html#gad68afc8d8b456735b17006b78b04ee5d", null ],
    [ "RfcLanguageSapToIso", "group__general.html#gaaeac3d604ae313b7b6ac84da5c5cb755", null ],
    [ "RfcReloadIniFile", "group__general.html#ga1e92a659190c4bb6b205ba4150f297a5", null ],
    [ "RfcSAPUCToUTF8", "group__general.html#gabf5a6a1f876eeff0f208ca16351c3765", null ],
    [ "RfcSetCpicTraceLevel", "group__general.html#ga5f5107158422e2b1acfc333878ccee10", null ],
    [ "RfcSetIniPath", "group__general.html#ga2f7ffd833c1731b223b7eca8e8521405", null ],
    [ "RfcSetTraceDir", "group__general.html#ga217228fcc730251e22974e3931d462cb", null ],
    [ "RfcSetTraceEncoding", "group__general.html#ga7144c6d15459820a452176b4dd4f4f4c", null ],
    [ "RfcSetTraceLevel", "group__general.html#ga6a1ac0e2b428366d0c9a0620d9039b91", null ],
    [ "RfcSetTraceType", "group__general.html#gad078c8b283b9ca30d8b26204ad1542b2", null ],
    [ "RfcUTF8ToSAPUC", "group__general.html#ga9b2495b8b8b9b4a08d2d626f97617afc", null ]
];