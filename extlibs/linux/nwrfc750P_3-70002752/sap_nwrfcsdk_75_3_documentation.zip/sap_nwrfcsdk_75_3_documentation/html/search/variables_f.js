var searchData=
[
  ['sattrace',['satTrace',['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a2828b0eec0a2cd6196d4be79a32a9e41',1,'_RFC_UNIT_ATTRIBUTES']]],
  ['sendingdate',['sendingDate',['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a97305a2c852ab9324b769a9eeb5295f3',1,'_RFC_UNIT_ATTRIBUTES']]],
  ['sendingtime',['sendingTime',['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#ad3b159f33f609e9bf5ce95252e4b5f98',1,'_RFC_UNIT_ATTRIBUTES']]],
  ['servername',['serverName',['../struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#ac8d3c6092a083507bc086063ffba4863',1,'_RFC_SERVER_ATTRIBUTES']]],
  ['sessionid',['sessionID',['../struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a207f0d41096ce7d377a194a912e1f22f',1,'_RFC_SERVER_CONTEXT::sessionID()'],['../struct___r_f_c___s_e_s_s_i_o_n___c_h_a_n_g_e.html#af2be0df0defe6aa5c00dbb607ecb1035',1,'_RFC_SESSION_CHANGE::sessionID()']]],
  ['sncname',['sncName',['../struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a4a46ea247323a1c5bd6510361c6e933b',1,'_RFC_SECURITY_ATTRIBUTES']]],
  ['ssoticket',['ssoTicket',['../struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#af384c9d6f380719f53019a96e5a71e6a',1,'_RFC_SECURITY_ATTRIBUTES']]],
  ['state',['state',['../struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a3e2a203abebaa1be07bd8c1a495f08ce',1,'_RFC_SERVER_ATTRIBUTES']]],
  ['sysid',['sysId',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ad2fb26bfc9de91496bd8980e2f9fec02',1,'_RFC_ATTRIBUTES::sysId()'],['../struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#ab779826559856ce36f7680cb3a17e6bd',1,'_RFC_SECURITY_ATTRIBUTES::sysId()']]],
  ['sysnumber',['sysNumber',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ab3fb88ef0bae9247b334d05563790811',1,'_RFC_ATTRIBUTES']]]
];
