var searchData=
[
  ['registrationcount',['registrationCount',['../struct___r_f_c___s_e_r_v_e_r___a_t_t_r_i_b_u_t_e_s.html#a96cd6e750dbe4df68266fbd5a3dd878e',1,'_RFC_SERVER_ATTRIBUTES']]],
  ['rel',['rel',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a567aecfc1561d1838fa919d9c9c053af',1,'_RFC_ATTRIBUTES']]],
  ['reserved',['reserved',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aea475f4e81935e14b8efe7e951f0c52b',1,'_RFC_ATTRIBUTES']]],
  ['rfcrole',['rfcRole',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a2d1baaeadb4106e201607089a4742c53',1,'_RFC_ATTRIBUTES']]]
];
