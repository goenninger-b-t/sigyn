var searchData=
[
  ['metadata_20for_20abap_20classes',['Metadata for ABAP classes',['../group__class.html',1,'']]],
  ['metadata_20for_20function_20modules',['Metadata for function modules',['../group__function.html',1,'']]],
  ['metadata_20and_20repository_20api',['Metadata and Repository API',['../group__repository.html',1,'']]],
  ['metadata_20for_20structures_2fline_2dtypes',['Metadata for structures/line-types',['../group__structure.html',1,'']]]
];
