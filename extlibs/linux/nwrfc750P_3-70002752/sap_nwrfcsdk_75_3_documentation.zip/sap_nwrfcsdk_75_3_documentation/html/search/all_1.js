var searchData=
[
  ['abap_5fapplication_5ffailure',['ABAP_APPLICATION_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a2012cb14e032dea966ae44aaaa97ebc2',1,'sapnwrfc.h']]],
  ['abap_5fruntime_5ffailure',['ABAP_RUNTIME_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a8ea73efa73dec715ac5f04dabb968643',1,'sapnwrfc.h']]],
  ['abapmsgclass',['abapMsgClass',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a91f050ab2868b67de897968c63d3528b',1,'_RFC_ERROR_INFO']]],
  ['abapmsgnumber',['abapMsgNumber',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a558ca41ca5667458a70e5ee6533af4a5',1,'_RFC_ERROR_INFO']]],
  ['abapmsgtype',['abapMsgType',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#ae7191cd6cc649719bac8c11464761199',1,'_RFC_ERROR_INFO']]],
  ['abapmsgv1',['abapMsgV1',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#abbfa86e77d892d0e655a5faaa8262f44',1,'_RFC_ERROR_INFO']]],
  ['abapmsgv2',['abapMsgV2',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#ade5e2adcd16fef6912e8eeb0c62fc02c',1,'_RFC_ERROR_INFO']]],
  ['abapmsgv3',['abapMsgV3',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a09d5b9978e758651880f320207a618a6',1,'_RFC_ERROR_INFO']]],
  ['abapmsgv4',['abapMsgV4',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#aba17bfcf7c5e2297fb42a6de31919725',1,'_RFC_ERROR_INFO']]],
  ['attributetype',['attributeType',['../struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a85276a2110fab5732839f0ae73d7a118',1,'_RFC_CLASS_ATTRIBUTE_DESC']]],
  ['api_20for_20automated_20servers',['API for Automated Servers',['../group__autoserver.html',1,'']]]
];
