var searchData=
[
  ['logon_5ffailure',['LOGON_FAILURE',['../sapnwrfc_8h.html#ga497758475b7ea26a55501399ec03a2e6a3bdd035e157f9618a0312f7ebac1919f',1,'sapnwrfc.h']]]
];
