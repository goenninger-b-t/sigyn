var struct___r_f_c___e_x_c_e_p_t_i_o_n___d_e_s_c =
[
    [ "key", "struct___r_f_c___e_x_c_e_p_t_i_o_n___d_e_s_c.html#a318101ce50c7d4ae9ac1d0ffb9b084b2", null ],
    [ "message", "struct___r_f_c___e_x_c_e_p_t_i_o_n___d_e_s_c.html#ae464627f568cc6750f4400d420b2b4db", null ]
];