var group__class =
[
    [ "RfcAddClassAttribute", "group__class.html#gafc7ef9297fcbcf5c2d730f4f629c8125", null ],
    [ "RfcAddImplementedInterface", "group__class.html#gaaf8f099c52cc433cd5d1c8d4badf3ffa", null ],
    [ "RfcAddParentClass", "group__class.html#ga3d7ef30d323956e4c9cafb15f039e1cb", null ],
    [ "RfcCreateClassDesc", "group__class.html#gaafef84fed4828337bb915abefd38382d", null ],
    [ "RfcDestroyClassDesc", "group__class.html#ga6189bbd3eae332318961e36da40b463b", null ],
    [ "RfcGetClassAttributeDescByIndex", "group__class.html#gab27b1aa9b7102785854751b140a214ec", null ],
    [ "RfcGetClassAttributeDescByName", "group__class.html#gac2df630728eefcdcd171b896e4f79025", null ],
    [ "RfcGetClassAttributesCount", "group__class.html#gace3f31b4bdd589a35d26b8f603eb2d46", null ],
    [ "RfcGetClassName", "group__class.html#ga5552ea12d8c952c84ecbf09d3eba9733", null ],
    [ "RfcGetImplementedInterfaceByIndex", "group__class.html#ga029ed6599d9ffbe8704af6c964a44e8c", null ],
    [ "RfcGetImplementedInterfacesCount", "group__class.html#gacca0d614ec6c737dda596418df425eb8", null ],
    [ "RfcGetParentClassByIndex", "group__class.html#ga75d809f7c54cebd874c054a7dcd576e7", null ],
    [ "RfcGetParentClassesCount", "group__class.html#ga539a9269a316d1e90b4ea3397fd22110", null ]
];