var group__connection =
[
    [ "API for Automated Servers", "group__autoserver.html", "group__autoserver" ],
    [ "_RFC_ATTRIBUTES", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html", [
      [ "client", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ab49af0266a6c233a16b63a555ad57cc9", null ],
      [ "codepage", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aa1b6f0b745762f13322d5d2c8e9f71bd", null ],
      [ "cpicConvId", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aa0d9fba558d08eb03d627a08d4612f8c", null ],
      [ "dest", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ac12ed9fe29f58d57ca8e00f4de5f8d26", null ],
      [ "host", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aa621cfc9ec084cb0a7077814f79cb114", null ],
      [ "isoLanguage", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aeeba183eac1c918a075bfc4f19ba07e8", null ],
      [ "kernelRel", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ae68384c12127e45b29f939aa92f64266", null ],
      [ "language", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a6ff947dc392f2787663eb8afd0e145a2", null ],
      [ "partnerBytesPerChar", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a321c5b7c3a8471e9a74ae252824378d1", null ],
      [ "partnerCodepage", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aec2e78f82ee5c3d800eecad38b228e5e", null ],
      [ "partnerHost", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a508cb905e22875779ebf7df7b316eb1d", null ],
      [ "partnerIP", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a296bc8d12035708fb178c2860433e29d", null ],
      [ "partnerIPv6", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aee6ab45062f5658c4fb69dae5860c232", null ],
      [ "partnerRel", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ae3c283f065e9523744096f081eaeac66", null ],
      [ "partnerSystemCodepage", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a45205858adb01b29ad63e11dfd8b74de", null ],
      [ "partnerType", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a5552895ebd47c6aed28a8600bda1093d", null ],
      [ "progName", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ad9f03d64a9d26b5b778ff8462e0ba870", null ],
      [ "rel", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a567aecfc1561d1838fa919d9c9c053af", null ],
      [ "reserved", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aea475f4e81935e14b8efe7e951f0c52b", null ],
      [ "rfcRole", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a2d1baaeadb4106e201607089a4742c53", null ],
      [ "sysId", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ad2fb26bfc9de91496bd8980e2f9fec02", null ],
      [ "sysNumber", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ab3fb88ef0bae9247b334d05563790811", null ],
      [ "trace", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aae258e8152c702f531c55f6ca78feabd", null ],
      [ "type", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a8e2610634ba3e8dd0f1ba8a04968f618", null ],
      [ "user", "struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#a64cf4508db46a45836272117d90f06ae", null ]
    ] ],
    [ "_RFC_SECURITY_ATTRIBUTES", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html", [
      [ "client", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a7363655e5a8aaf96d228e24f1444b12a", null ],
      [ "functionName", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a5e1f0e4935068ff402dab41501a553e7", null ],
      [ "progName", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a73c1cb8b9aeaa112bcb39bbf499814c3", null ],
      [ "sncName", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a4a46ea247323a1c5bd6510361c6e933b", null ],
      [ "ssoTicket", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#af384c9d6f380719f53019a96e5a71e6a", null ],
      [ "sysId", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#ab779826559856ce36f7680cb3a17e6bd", null ],
      [ "user", "struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a612941028fb8bf5cc4931a75969757f3", null ]
    ] ],
    [ "_RFC_SERVER_CONTEXT", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html", [
      [ "isStateful", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#abea327b10e8075d8a1d85a29d4c4f8a6", null ],
      [ "sessionID", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a207f0d41096ce7d377a194a912e1f22f", null ],
      [ "tid", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#abc60d0479b6ae2895d06ea6bdb4a7968", null ],
      [ "type", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a74d22c358223c858de6e4acf0bef1a7b", null ],
      [ "unitAttributes", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#ae2acb7f8330409986df568236cb3a737", null ],
      [ "unitIdentifier", "struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a7ff76c4728c04654781c70659f6aeb27", null ]
    ] ],
    [ "_RFC_CONNECTION_HANDLE", "struct___r_f_c___c_o_n_n_e_c_t_i_o_n___h_a_n_d_l_e.html", [
      [ "handle", "struct___r_f_c___c_o_n_n_e_c_t_i_o_n___h_a_n_d_l_e.html#a5b7f0bf4b9ae820582c8ea4acc3af9f2", null ]
    ] ],
    [ "_RFC_CONNECTION_PARAMETER", "struct___r_f_c___c_o_n_n_e_c_t_i_o_n___p_a_r_a_m_e_t_e_r.html", [
      [ "name", "struct___r_f_c___c_o_n_n_e_c_t_i_o_n___p_a_r_a_m_e_t_e_r.html#ab9ee37f3a03f41a4b2720d2acb0a1546", null ],
      [ "value", "struct___r_f_c___c_o_n_n_e_c_t_i_o_n___p_a_r_a_m_e_t_e_r.html#a3f32db2848d8c8896cbda8208ed5fa7b", null ]
    ] ],
    [ "_RFC_CALL_TYPE", "group__connection.html#ga7d7f6b124829f02177a13f91ef3074b3", [
      [ "RFC_SYNCHRONOUS", "sapnwrfc_8h.html#ga7d7f6b124829f02177a13f91ef3074b3ae1860c20112c2cf0bf6ad7b56e1fe714", null ],
      [ "RFC_TRANSACTIONAL", "sapnwrfc_8h.html#ga7d7f6b124829f02177a13f91ef3074b3ad1bed3a8c9ac6e14dab887a8d072e3d8", null ],
      [ "RFC_QUEUED", "sapnwrfc_8h.html#ga7d7f6b124829f02177a13f91ef3074b3a6e19548f27396ea67dbc9b48341f0f03", null ],
      [ "RFC_BACKGROUND_UNIT", "sapnwrfc_8h.html#ga7d7f6b124829f02177a13f91ef3074b3ab2b81805f9f881276556941bfbbfd521", null ]
    ] ],
    [ "_RFC_PROTOCOL_TYPE", "group__connection.html#ga92d7f99e875e511d9b7c6a440bd42c78", [
      [ "RFC_UNKOWN", "sapnwrfc_8h.html#ga92d7f99e875e511d9b7c6a440bd42c78aea7df97668d62b7bd4fcc0a67e7cab3a", null ],
      [ "RFC_CLIENT", "sapnwrfc_8h.html#ga92d7f99e875e511d9b7c6a440bd42c78ac71cc00449495c569ae959cfa8066025", null ],
      [ "RFC_STARTED_SERVER", "sapnwrfc_8h.html#ga92d7f99e875e511d9b7c6a440bd42c78acb5fc8df2e78e4508b2c64a3e6ebdbe6", null ],
      [ "RFC_REGISTERED_SERVER", "sapnwrfc_8h.html#ga92d7f99e875e511d9b7c6a440bd42c78ad85874a9de1788353361b09d02810848", null ],
      [ "RFC_MULTI_COUNT_REGISTERED_SERVER", "sapnwrfc_8h.html#ga92d7f99e875e511d9b7c6a440bd42c78a05fe8342a15f8e0ddc68e82656b0d7ec", null ],
      [ "RFC_TCP_SOCKET_CLIENT", "sapnwrfc_8h.html#ga92d7f99e875e511d9b7c6a440bd42c78a2601c3bc85a8ea13f13635dc64d0841d", null ],
      [ "RFC_TCP_SOCKET_SERVER", "sapnwrfc_8h.html#ga92d7f99e875e511d9b7c6a440bd42c78af3afe9c8aac3402994f2506cf7847f59", null ]
    ] ],
    [ "RfcCancel", "group__connection.html#ga2b2e321f3f8690551ce42627c951491e", null ],
    [ "RfcCloseConnection", "group__connection.html#ga16a8ffcc4f312139a4ba2007decad52e", null ],
    [ "RfcFreeSaplogonEntries", "group__connection.html#ga6f676842c1ae66a3e19fef2cdf07487a", null ],
    [ "RfcFreeSaplogonEntry", "group__connection.html#gad88b2d5502283f39e04167f222825ba0", null ],
    [ "RfcGetConnectionAttributes", "group__connection.html#gae94fe2811994cdfc5c4a01e9d3d5e1c1", null ],
    [ "RfcGetPartnerSNCKey", "group__connection.html#ga1186f3d9d4de672559129c5cabac9de8", null ],
    [ "RfcGetPartnerSNCName", "group__connection.html#ga2e8dc80afeae913d42ca714acf82d66d", null ],
    [ "RfcGetPartnerSSOTicket", "group__connection.html#gadce79e66cccc01e3903028efc27d13dd", null ],
    [ "RfcGetSaplogonEntries", "group__connection.html#gacbe80c84bf810186296b338e4db08767", null ],
    [ "RfcGetSaplogonEntry", "group__connection.html#ga5724f941d0ccfe7e20d877a117b558a5", null ],
    [ "RfcGetSapRouter", "group__connection.html#gae85d791f66f85010c438af940f324635", null ],
    [ "RfcGetServerContext", "group__connection.html#gae58bf10acb0bd367f2895c6ca9b9bee5", null ],
    [ "RfcInvoke", "group__connection.html#gaf31c5a70f00396988981950c6fc5bd38", null ],
    [ "RfcIsConnectionHandleValid", "group__connection.html#gab4c1d78a3200e79b07c3f4954016a20f", null ],
    [ "RfcListenAndDispatch", "group__connection.html#gae82e9d2551446b249b8b92e8395ea1f5", null ],
    [ "RfcOpenConnection", "group__connection.html#ga6a124d147dd33fa6055d7f975be525e0", null ],
    [ "RfcPing", "group__connection.html#ga2cc195c7e182e255832092ac9b8cc7f7", null ],
    [ "RfcRegisterServer", "group__connection.html#ga1f6adc42c38ab0690d380d19c953e81c", null ],
    [ "RfcResetServerContext", "group__connection.html#ga4eed7b4d07e528d1fff1d1119c2ab561", null ],
    [ "RfcSNCKeyToName", "group__connection.html#ga091379860178541579eb7285ef901658", null ],
    [ "RfcSNCNameToKey", "group__connection.html#gacfdcda5af286806b162147f2c7ed57b4", null ],
    [ "RfcStartServer", "group__connection.html#ga2567c2a419062097f31d13e6f80ebfa3", null ]
];