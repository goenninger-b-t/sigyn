var struct___r_f_c___t_h_r_o_u_g_h_p_u_t___h_a_n_d_l_e =
[
    [ "handle", "struct___r_f_c___t_h_r_o_u_g_h_p_u_t___h_a_n_d_l_e.html#acae79cf493d79c2233834096991dfb9a", null ]
];