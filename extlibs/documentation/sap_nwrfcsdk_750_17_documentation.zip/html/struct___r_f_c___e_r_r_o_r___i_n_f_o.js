var struct___r_f_c___e_r_r_o_r___i_n_f_o =
[
    [ "abapMsgClass", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a91f050ab2868b67de897968c63d3528b", null ],
    [ "abapMsgNumber", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a558ca41ca5667458a70e5ee6533af4a5", null ],
    [ "abapMsgType", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#ae7191cd6cc649719bac8c11464761199", null ],
    [ "abapMsgV1", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#abbfa86e77d892d0e655a5faaa8262f44", null ],
    [ "abapMsgV2", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#ade5e2adcd16fef6912e8eeb0c62fc02c", null ],
    [ "abapMsgV3", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a09d5b9978e758651880f320207a618a6", null ],
    [ "abapMsgV4", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#aba17bfcf7c5e2297fb42a6de31919725", null ],
    [ "code", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a136ec745ede4687b7b1520b8badeddc6", null ],
    [ "group", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a79e77174e9904277de70ebadfd3aff55", null ],
    [ "key", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a71a3bde15c92060d227b08da0c03c0ba", null ],
    [ "message", "struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a42a530e1c629e94a5e7b0529c42553bf", null ]
];