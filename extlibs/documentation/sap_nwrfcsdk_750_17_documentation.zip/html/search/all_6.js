var searchData=
[
  ['false',['FALSE',['../doxyfile__nrfc__public_8h.html#aa93f0eb578d23995850d61f7d61c55c1',1,'doxyfile_nrfc_public.h']]],
  ['functionmodulename',['functionModuleName',['../struct___r_f_c___s_e_r_v_e_r___m_o_n_i_t_o_r___d_a_t_a.html#a648796ea999c2cdd88eaa4b5e70d2813',1,'_RFC_SERVER_MONITOR_DATA']]],
  ['functionname',['functionName',['../struct___r_f_c___s_e_c_u_r_i_t_y___a_t_t_r_i_b_u_t_e_s.html#a5e1f0e4935068ff402dab41501a553e7',1,'_RFC_SECURITY_ATTRIBUTES']]]
];
