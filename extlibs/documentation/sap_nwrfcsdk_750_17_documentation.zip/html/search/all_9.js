var searchData=
[
  ['installation_20of_20callback_20functions_20for_20rfc_20servers',['Installation of Callback Functions for RFC Servers',['../group__installer.html',1,'']]],
  ['isactive',['isActive',['../struct___r_f_c___s_e_r_v_e_r___m_o_n_i_t_o_r___d_a_t_a.html#a25589ec13b6fda68a2c28891e79ea9dd',1,'_RFC_SERVER_MONITOR_DATA']]],
  ['isolanguage',['isoLanguage',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#aeeba183eac1c918a075bfc4f19ba07e8',1,'_RFC_ATTRIBUTES']]],
  ['isreadonly',['isReadOnly',['../struct___r_f_c___c_l_a_s_s___a_t_t_r_i_b_u_t_e___d_e_s_c.html#a1d84ef9a2a9bd5336cf81fc9411a296d',1,'_RFC_CLASS_ATTRIBUTE_DESC']]],
  ['isstateful',['isStateful',['../struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#abea327b10e8075d8a1d85a29d4c4f8a6',1,'_RFC_SERVER_CONTEXT::isStateful()'],['../struct___r_f_c___s_e_r_v_e_r___m_o_n_i_t_o_r___d_a_t_a.html#a5b17bac430d19365d5def2627d33c3bc',1,'_RFC_SERVER_MONITOR_DATA::isStateful()']]],
  ['issuer',['issuer',['../struct___r_f_c___c_e_r_t_i_f_i_c_a_t_e___d_a_t_a.html#a8ace66d00e38a7b8940c3c6cec996b34',1,'_RFC_CERTIFICATE_DATA']]]
];
