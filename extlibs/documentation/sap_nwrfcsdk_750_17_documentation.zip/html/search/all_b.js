var searchData=
[
  ['kernelrel',['kernelRel',['../struct___r_f_c___a_t_t_r_i_b_u_t_e_s.html#ae68384c12127e45b29f939aa92f64266',1,'_RFC_ATTRIBUTES']]],
  ['kerneltrace',['kernelTrace',['../struct___r_f_c___u_n_i_t___a_t_t_r_i_b_u_t_e_s.html#a0e0e1d5663b4ec47612352cf8120ad02',1,'_RFC_UNIT_ATTRIBUTES']]],
  ['key',['key',['../struct___r_f_c___e_r_r_o_r___i_n_f_o.html#a71a3bde15c92060d227b08da0c03c0ba',1,'_RFC_ERROR_INFO::key()'],['../struct___r_f_c___e_x_c_e_p_t_i_o_n___d_e_s_c.html#a318101ce50c7d4ae9ac1d0ffb9b084b2',1,'_RFC_EXCEPTION_DESC::key()']]]
];
