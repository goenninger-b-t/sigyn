var searchData=
[
  ['queuenames',['queueNames',['../struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#aeca6c17404028a70f3068ee4e3e7af4e',1,'_RFC_SERVER_CONTEXT']]],
  ['queuenamescount',['queueNamesCount',['../struct___r_f_c___s_e_r_v_e_r___c_o_n_t_e_x_t.html#a0b6734a3c676a544265ab38a1fc4ad98',1,'_RFC_SERVER_CONTEXT']]]
];
