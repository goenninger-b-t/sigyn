var searchData=
[
  ['sap_5fapi',['SAP_API',['../sapnwrfc_8h.html#a727b1b47d3b82e6f4aa6d3e55481f9fa',1,'sapnwrfc.h']]],
  ['sap_5fo_5fk',['SAP_O_K',['../doxyfile__nrfc__public_8h.html#a9ecab66718e0e86b6614bb1a83d05774',1,'doxyfile_nrfc_public.h']]]
];
